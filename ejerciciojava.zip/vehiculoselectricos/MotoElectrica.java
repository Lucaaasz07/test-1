package vehiculoselectricos;

public class MotoElectrica extends Vehiculo implements Beneficio {

    private String marca;
    private String modelo;
    private int autonomiaKm;
    private String tipoMoto;
    private double incremento;
    private double bonificacion;
    private double ajuste;

    public MotoElectrica(String codigo, String nombre, double precioBase, String marca, String modelo, int autonomiaKm, String tipoMoto) {
        super(codigo, nombre, precioBase);
        this.marca = marca;
        this.modelo = modelo;
        this.autonomiaKm = autonomiaKm;
        this.tipoMoto = tipoMoto;
        this.incremento = 0;
        this.bonificacion = 0;
        this.ajuste = 0;
    }

    @Override
    public double aplicarBonificacion() {
        if (tipoMoto.equalsIgnoreCase("Deportiva")) {
            bonificacion = precioBase * 0.02;
        }
        return bonificacion;
    }

    public void aplicarIncremento() {
        if (autonomiaKm > 250) {
            incremento = 420000;
        }
    }

    public void aplicarAjuste() {
        ajuste = 0;
    }

    @Override
    public double calcularPrecioFinal() {
        aplicarIncremento();
        aplicarBonificacion();
        return precioBase - ajuste + incremento + bonificacion;
    }

    public String getModelo() {
        return modelo;
    }
}
