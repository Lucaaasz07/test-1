package vehiculoselectricos;

import java.time.Year;

public class AutoElectrico extends Vehiculo implements Beneficio {

    private String marca;
    private String modelo;
    private int anioFabricacion;
    private String tipoAuto;
    private double descuento;
    private double ajuste;

    public AutoElectrico(String codigo, String nombre, double precioBase, String marca, String modelo, int anioFabricacion, String tipoAuto) {
        super(codigo, nombre, precioBase);
        this.marca = marca;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
        this.tipoAuto = tipoAuto;
        this.descuento = 0;
        this.ajuste = 0;
    }

    @Override
    public double aplicarBonificacion() {
        if (tipoAuto.equalsIgnoreCase("SUV")) {
            return precioBase * BONIFICACION_BASE;
        }
        return 0;
    }

    public void aplicarDescuento() {
        int anioActual = Year.now().getValue();
        if (anioActual - anioFabricacion > 8) {
            descuento = precioBase * 0.03;
        }
    }

    public void aplicarAjuste() {
        if (anioFabricacion < 2015) {
            ajuste = precioBase * 0.12;
        }
    }

    @Override
    public double calcularPrecioFinal() {
        aplicarDescuento();
        aplicarAjuste();
        double bonificacion = aplicarBonificacion();
        return precioBase - ajuste - descuento + bonificacion;
    }

    public String getModelo() {
        return modelo;
    }
}
