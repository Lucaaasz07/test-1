package vehiculoselectricos;

public interface Beneficio {
    double BONIFICACION_BASE = 0.055;

    double aplicarBonificacion();
}
