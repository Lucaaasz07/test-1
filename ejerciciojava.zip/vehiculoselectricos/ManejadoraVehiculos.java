package vehiculoselectricos;

import java.util.ArrayList;
import java.util.Scanner;

public class ManejadoraVehiculos {

    private ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();

    public void menu() {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("=== MENU VEHICULOS ELECTRICOS ===");
            System.out.println("1. Ingresar vehiculo");
            System.out.println("2. Mostrar precio final por codigo");
            System.out.println("3. Aplicar ajuste de precios");
            System.out.println("4. Mostrar cantidad de vehiculos y modelos");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    ingresarVehiculo(sc);
                    break;
                case 2:
                    mostrarPrecioFinal(sc);
                    break;
                case 3:
                    aplicarAjustePrecios();
                    break;
                case 4:
                    mostrarCantidadVehiculos();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 5);
    }

    private void ingresarVehiculo(Scanner sc) {
        System.out.print("Ingrese codigo: ");
        String codigo = sc.nextLine();

        for (Vehiculo v : listaVehiculos) {
            if (v.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("El vehiculo ya existe.");
                return;
            }
        }

        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese precio base: ");
        double precioBase = sc.nextDouble();
        sc.nextLine();

        System.out.print("Tipo de vehiculo (Auto/Moto): ");
        String tipo = sc.nextLine();

        if (tipo.equalsIgnoreCase("Auto")) {
            System.out.print("Marca: ");
            String marca = sc.nextLine();
            System.out.print("Modelo: ");
            String modelo = sc.nextLine();
            System.out.print("Anio de fabricacion: ");
            int anio = sc.nextInt();
            sc.nextLine();
            System.out.print("Tipo de auto (Sedan/SUV): ");
            String tipoAuto = sc.nextLine();

            listaVehiculos.add(new AutoElectrico(codigo, nombre, precioBase, marca, modelo, anio, tipoAuto));
            System.out.println("Auto ingresado con exito.");

        } else if (tipo.equalsIgnoreCase("Moto")) {
            System.out.print("Marca: ");
            String marca = sc.nextLine();
            System.out.print("Modelo: ");
            String modelo = sc.nextLine();
            System.out.print("Autonomia en km: ");
            int autonomia = sc.nextInt();
            sc.nextLine();
            System.out.print("Tipo de moto (Ciudad/Deportiva): ");
            String tipoMoto = sc.nextLine();

            listaVehiculos.add(new MotoElectrica(codigo, nombre, precioBase, marca, modelo, autonomia, tipoMoto));
            System.out.println("Moto ingresada con exito.");

        } else {
            System.out.println("Tipo de vehiculo no valido.");
        }
    }

    private void mostrarPrecioFinal(Scanner sc) {
        System.out.print("Ingrese el codigo del vehiculo: ");
        String codigo = sc.nextLine();

        for (Vehiculo v : listaVehiculos) {
            if (v.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("El precio final del vehiculo es: $" + v.calcularPrecioFinal());
                return;
            }
        }
        System.out.println("Vehiculo no encontrado.");
    }

    private void aplicarAjustePrecios() {
        for (Vehiculo v : listaVehiculos) {
            if (v instanceof AutoElectrico) {
                ((AutoElectrico) v).aplicarAjuste();
            } else if (v instanceof MotoElectrica) {
                ((MotoElectrica) v).aplicarAjuste();
            }
        }
        System.out.println("Ajuste de precios aplicado a los vehiculos.");
    }

    private void mostrarCantidadVehiculos() {
        System.out.println("Cantidad de vehiculos ingresados: " + listaVehiculos.size());
        for (Vehiculo v : listaVehiculos) {
            if (v instanceof AutoElectrico) {
                System.out.println("Auto modelo: " + ((AutoElectrico) v).getModelo());
            } else if (v instanceof MotoElectrica) {
                System.out.println("Moto modelo: " + ((MotoElectrica) v).getModelo());
            }
        }
    }
}
