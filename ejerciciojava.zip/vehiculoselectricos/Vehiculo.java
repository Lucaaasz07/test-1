package vehiculoselectricos;

public abstract class Vehiculo {
    protected String codigo;
    protected String nombre;
    protected double precioBase;

    public Vehiculo(String codigo, String nombre, double precioBase) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precioBase = precioBase;
    }

    public String getCodigo() {
        return codigo;
    }

    public abstract double calcularPrecioFinal();
}
