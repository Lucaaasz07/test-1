package vehiculoselectricos;

public class Main {
    public static void main(String[] args) {
        ManejadoraVehiculos manejadora = new ManejadoraVehiculos();
        manejadora.menu();
    }
}
